import numpy as np
# This is the only scipy method you are allowed to use
# Use of scipy is not allowed otherwise
from scipy.linalg import khatri_rao
import random as rnd
import time as tm

# In[2]:


'''
	Package: cs771
	Module: helloWorld
	Author: Puru (purushot@cse.iitk.ac.in)
	Institution: CSE, IIT Kanpur
	License: GNU GPL v3.0

	Generate synthetic data of various sorts
'''

import numpy as np
import numpy.linalg as nplin
import numpy.random as nprnd


# Return n data points (as an n x d array) sampled from the surface of sphere of radius r centered at mu
def genSphericalData(d, n, mu, r):
	X = nprnd.normal(0, 1, (n, d))
	norms = nplin.norm(X, axis=1)
	X = X / norms[:, np.newaxis]
	X = (X * r) + mu
	return X


# Return n data points (as an n x d array) sampled from the surface of ellipse of covariance cov centered at mu
def genEllipticalData(d, n, mu, cov):
	X = genSphericalData(d, n, np.zeros((d,)), 1)
	L = nplin.cholesky(cov)
	X = np.matmul(X, L) + mu
	return X


# Return n data points (as an n x d array) sampled from N(mu, sigma^2 . I)
def genSphericalNormalData(d, n, mu, sigma):
	X = nprnd.normal(0, sigma, (n, d)) + mu
	return X


# Return n data points (as an n x d array) sampled from N(mu, cov)
def genNormalData(d, n, mu, cov):
	X = nprnd.multivariate_normal(mu, cov, n)
	return X


# Return n data points (as an n x d array) shaped as a hemisphere
# The manner of generation used below is similar to the sklearn
# method make_moons.However, the method below gives the additional
# flexibility of flipping and translating the moons
def genMoonData(d, n, mu, r, flipped=False):
	X = np.vstack((np.cos(np.linspace(0, np.pi, n)), np.sin(np.linspace(0, np.pi, n)))).T
	if flipped:
		X[:, 1] = -np.abs(X[:, 1])
	else:
		X[:, 1] = np.abs(X[:, 1])
	X = (X * r) + mu
	return X


# In[3]:


'''
	Package: cs771
	Module: plotData
	Author: Puru (purushot@cse.iitk.ac.in)
	Institution: CSE, IIT Kanpur
	License: GNU GPL v3.0

	Plot 2D data in various ways to visualize classifiers and other things
'''

from matplotlib import pyplot as plt
from matplotlib.colors import LinearSegmentedColormap as lsc
import numpy as np

# A light red and light green binary colormap
binaryColors = [(1, 0.85, 0.85), (0.85, 1, 0.85)]
nBins = 2
lrlg = lsc.from_list('lrlg', binaryColors, nBins)

# A light red and light green binary colormap with shades
probColors = [(1, 0.75, 0.75), (1, 1, 1), (0.75, 1, 0.75)]
nBinsShade = 200
lrlgShade = lsc.from_list('lrlg', probColors, nBinsShade)

# A more gradual transition with more room for white shades
probColorsGradual = [(1, 0.75, 0.75), (1, 1, 1), (1, 1, 1), (0.75, 1, 0.75)]
nBinsShade = 200
lrlgShadeGradual = lsc.from_list('lrlg', probColorsGradual, nBinsShade)


def getFigure(sizex=7, sizey=7):
	fig = plt.figure(figsize=(sizex, sizey))
	return fig


def getFigList(nrows=1, ncols=1, sizex=3, sizey=3):
	fig, axs = plt.subplots(nrows=nrows, ncols=ncols, figsize=(sizex * ncols, sizey * nrows), squeeze=0)
	axs = axs.reshape(-1)
	return (fig, axs)


def showImagesNoAxes(axes, imageList, numRows, numCols, resize=False, imShape=[], cmap=plt.cm.gray_r, labelList=[]):
	for i in range(numRows * numCols):
		currAxis = axes[i]
		im = imageList[i]
		if resize:
			# Reshaping an indexed element of an array does not modify the original data so we are safe
			im = im.reshape(imShape)
		currAxis.imshow(im, cmap=cmap, interpolation='nearest')
		currAxis.tick_params(axis='x', which="both", bottom=False, labelbottom=False)
		currAxis.tick_params(axis='y', which="both", left=False, labelleft=False)
		if labelList:
			currAxis.set_title(labelList[i])


def plotCurve(responseGenerator, fig, mode="point", color='b', linestyle="-", xlimL=0, xlimR=10, nBins=500, label=""):
	X = np.linspace(xlimL, xlimR, nBins, endpoint=True)
	if mode == "point":
		y = np.zeros(X.shape)
		for i in range(X.size):
			y[i] = responseGenerator(X[i])
	elif mode == "batch":
		y = responseGenerator(X)
	plt.figure(fig.number)
	plt.plot(X, y, color=color, linestyle=linestyle, label=label)
	if label:
		plt.legend()


def plot2D(X, fig, color='r', marker='+', size=100, empty=False, label=""):
	plt.figure(fig.number)
	if empty:
		plt.scatter(X[:, 0], X[:, 1], s=size, facecolors='none', edgecolors=color, marker=marker, label=label)
	else:
		plt.scatter(X[:, 0], X[:, 1], s=size, c=color, marker=marker, label=label)
	if label:
		plt.legend()


def subplot2D(X, ax, color='r', marker='+', size=100, empty=False, label=""):
	if empty:
		ax.scatter(X[:, 0], X[:, 1], s=size, facecolors='none', edgecolors=color, marker=marker, label=label)
	else:
		ax.scatter(X[:, 0], X[:, 1], s=size, c=color, marker=marker, label=label)
	if label:
		plt.legend()


def plot2DPoint(X, fig, color='r', marker='+', size=100, label=""):
	plt.figure(fig.number)
	plt.scatter(X[0], X[1], s=size, c=color, marker=marker, label=label)
	if label:
		plt.legend()


def plotLine(w, b, fig, color='k', linestyle="-", xlimL=-10, xlimR=10, ylimD=-10, ylimU=10, nBins=500, label=""):
	plt.figure(fig.number)
	if np.abs(w[1]) < 1e-6:
		y = np.linspace(xlimL, xlimR, nBins)
		x = -b / w[0] * np.ones(y.shape)
	else:
		x = np.linspace(xlimL, xlimR, nBins)
		y = (-w[0] * x - b) / w[1]

	idx = (y > ylimD) & (y < ylimU)
	plt.plot(x[idx], y[idx], color=color, linestyle=linestyle, label=label)
	if label:
		plt.legend()


def plotVerticalLine(x, fig, color='k', linestyle='-', yLimB=-10, yLimT=10, nBins=500, label=""):
	plt.figure(fig.number)
	y = np.linspace(yLimB, yLimT, nBins)
	plt.plot(x * np.ones(y.shape), y, color=color, linestyle=linestyle, label=label)
	if label:
		plt.legend()


def shade2D(labelGenerator, fig, mode="point", colorMap=lrlg, xlim=10, ylim=10, nBins=500):
	xi, yi = np.mgrid[-xlim:xlim:nBins * 1j, -ylim:ylim:nBins * 1j]
	zi = np.zeros(xi.shape)
	if mode == "point":
		for i in range(zi.shape[0]):
			for j in range(zi.shape[1]):
				zi[i, j] = labelGenerator(xi[i, j], yi[i, j])
	elif mode == "batch":
		zi = labelGenerator(np.hstack((xi.reshape((xi.size, 1)), yi.reshape((yi.size, 1)))))
		zi = zi.reshape(xi.shape)
	zi[zi < 1 / nBins] = 0
	zi[zi > 0] = 1
	plt.figure(fig.number)
	plt.pcolormesh(xi, yi, zi, cmap=colorMap)


def shade2DProb(scoreGenerator, fig, mode="point", colorMap=lrlgShadeGradual, xlim=10, ylim=10, nBins=500):
	xi, yi = np.mgrid[-xlim:xlim:nBins * 1j, -ylim:ylim:nBins * 1j]
	zi = np.zeros(xi.shape)
	if mode == "point":
		for i in range(zi.shape[0]):
			for j in range(zi.shape[1]):
				zi[i, j] = scoreGenerator(xi[i, j], yi[i, j])
	elif mode == "batch":
		zi = scoreGenerator(np.hstack((xi.reshape((xi.size, 1)), yi.reshape((yi.size, 1)))))
		zi = zi.reshape(xi.shape)
	plt.figure(fig.number)
	plt.pcolormesh(xi, yi, zi, cmap=colorMap)


# In[4]:


'''
	Package: cs771
	Module: optLib
	Author: Puru
	Institution: CSE, IIT Kanpur
	License: GNU GPL v3.0

	Give skeletal support for implementing various optimization techniques like gradient and coordinate methods
'''

import numpy as np
from matplotlib import pyplot as plt
import time as t
import random


# The word "oracle", as used below, refers for a function that does a certain job to our satisfaction.
# For example, our step length oracle returns a step length value whenever we ask it, the gradient
# oracle always returns a direction either by calculating the gradient, or the (mini-batch) stochastic gradient

# Get functions that offer various step length sequences. The constant step length scheme is only suitable for
# "superbly nice" functions that satisfy two properties known as "strong convexity" and "strong smoothness".
# The quadratic scheme decreases step lengths gradually and is a good choice for several cases, whether "nice" or not.
# The linear scheme decreases step lengths fairly rapidly and is suitable for functions with intermediate "niceness".
# Examples include strongly convex functions that are not strongly smooth (the CSVM objective is one such example) or
# strongly smooth functions that are not strongly convex.
def stepLengthGenerator(mode, eta):
	if mode == "constant":
		return lambda t: eta
	elif mode == "linear":
		return lambda t: eta / (t + 1)
	elif mode == "quadratic":
		return lambda t: eta / np.sqrt(t + 1)


# Given a gradient oracle and a steplength oracle, implement the gradient descent method
# The method returns the final model and the objective value acheived by the intermediate models
# This can be used to implement (mini-batch) SGD as well by simply modifying the gradient oracle
# The postGradFunc can be used to implement projections or thresholding operations
def doGD(gradFunc, stepFunc, objFunc, init, horizon=10, doModelAveraging=False, postGradFunc=None):
	objValSeries = []
	timeSeries = []
	totTime = 0
	theta = init
	cumulative = init

	for it in range(horizon):
		# Start a stopwatch to calculate how much time we are spending
		tic = t.perf_counter()
		delta = gradFunc(theta, it + 1)
		theta = theta - stepFunc(it + 1) * delta
		if postGradFunc is not None:
			theta = postGradFunc(theta, it + 1)
		# If we are going to do model averaging, just keep adding the models
		if doModelAveraging:
			cumulative = cumulative + theta
		else:
			cumulative = theta
		# All calculations done -- stop the stopwatch
		toc = t.perf_counter()
		totTime = totTime + (toc - tic)
		# If model averaging is being done, need to calculate current objective value a bit differently
		if doModelAveraging:
			objValSeries.append(objFunc(cumulative / (it + 2)))
		else:
			objValSeries.append(objFunc(cumulative))
		timeSeries.append(totTime)

	# Clean up the final model
	if doModelAveraging:
		final = cumulative / (horizon + 1)
	else:
		final = cumulative

	# Return the final model and the objective values obtained at various time steps
	return (final, objValSeries, timeSeries)


# For cyclic mode, the state is a tuple of the current coordinate and the number of dimensions
def getCyclicCoord(state):
	curr = state[0]
	d = state[1]
	if curr >= d - 1 or curr < 0:
		curr = 0
	else:
		curr += 1
	state = (curr, d)
	return (curr, state)


# For random mode, the state is the number of dimensions
def getRandCoord(state):
	d = state
	curr = random.randint(0, d - 1)
	state = d
	return (curr, state)


# For randperm mode, the state is a tuple of the random permutation and the current index within that permutation
def getRandpermCoord(state):
	idx = state[0]
	perm = state[1]
	d = len(perm)
	if idx >= d - 1 or idx < 0:
		idx = 0
		perm = np.random.permutation(d)
	else:
		idx += 1
	state = (idx, perm)
	curr = perm[idx]
	return (curr, state)


# Get functions that offer various coordinate selection schemes
def coordinateGenerator(mode, d):
	if mode == "cyclic":
		return (getCyclicCoord, (0, d))
	elif mode == "random":
		return (getRandCoord, d)
	elif mode == "randperm":
		return (getRandpermCoord, (0, np.random.permutation(d)))


# Given a coordinate update oracle and a coordinate selection oracle, implement coordinate methods
# The method returns the final model and the objective value acheived by the intermediate models
# This can be used to implement coordinate descent or ascent as well as coordinate minimization or
# maximization methods simply by modifying the coordinate update oracle
def doSDCM(coordUpdateFunc, getCoordFunc, objFunc, init, horizon=10):
	objValSeries = []
	timeSeries = []
	totTime = 0
	selector = getCoordFunc[0]  # Get hold of the function that will give me the next coordinate
	state = getCoordFunc[1]  # The function needs an internal state variable - store the initial state

	# Initialize model as well as some bookkeeping variables
	alpha = init

	for it in range(horizon):
		# Start a stopwatch to calculate how much time we are spending
		tic = t.perf_counter()

		# Get the next coordinate to update and update that coordinate
		(i, state) = selector(state)
		alpha[i] = coordUpdateFunc(alpha, i, it)

		toc = t.perf_counter()
		totTime = totTime + (toc - tic)

		objValSeries.append(objFunc(alpha))
		timeSeries.append(totTime)

	return (alpha, objValSeries, timeSeries)


# In[5]:


################################
# Non Editable Region Starting #
################################
def get_renamed_labels(y):
	################################
	#  Non Editable Region Ending  #
	################################
	y_new = 2 * y - 1
	return y_new


# Since the dataset contain 0/1 labels and SVMs prefer -1/+1 labels,
# Decide here how you want to rename the labels
# For example, you may map 1 -> 1 and 0 -> -1 or else you may want to go with 1 -> -1 and 0 -> 1
# Use whatever convention you seem fit but use the same mapping throughout your code
# If you use one mapping for train and another for test, you will get poor accuracy

# 	return y_new.reshape( ( y_new.size, ) )					# Reshape y_new as a vector


# In[6]:


def createFeatures(X):
	return np.cumprod(np.flip(2 * X - 1, axis=1), axis=1)


# In[7]:


################################
# Non Editable Region Starting #
################################
def get_features(X):
	################################
	#  Non Editable Region Ending  #
	################################
	X = createFeatures(X)
	X_new = khatri_rao(X.T, khatri_rao(X.T, X.T)).T
	# Use this function to transform your input features (that are 0/1 valued)
	# into new features that can be fed into a linear model to solve the problem
	# Your new features may have a different dimensionality than the input features
	# For example, in this application, X will be 8 dimensional but your new
	# features can be 2 dimensional, 10 dimensional, 1000 dimensional, 123456 dimensional etc
	# Keep in mind that the more dimensions you use, the slower will be your solver too
	# so use only as many dimensions as are absolutely required to solve the problem
	return X_new


# In[8]:


def mySVM(X):
	return X.dot(w) + b


# Stochastic Dual Coordinate Maximization
def doCoordOptCSVMDual(alpha, i, t):
	global w_SDCM, b_SDCM, normSq
	x = X[i, :]

	# Find the unconstrained new optimal value of alpha_i
	# It takes only O(d) time to do so because of our clever book keeping
	newAlphai = alpha[i] + (1 - y[i] * (x.dot(w_SDCM) + b_SDCM)) / normSq[i]

	# Make sure that the constraints are satisfied. This takes only O(1) time
	if newAlphai > C:
		newAlphai = C
	if newAlphai < 0:
		newAlphai = 0

	# Update the primal model vector and bias values to ensure bookkeeping is proper
	# Doing these bookkeeping updates also takes only O(d) time
	w_SDCM = w_SDCM + (newAlphai - alpha[i]) * y[i] * x
	b_SDCM = b_SDCM + (newAlphai - alpha[i]) * y[i]

	return newAlphai


# Get the primal and the dual CSVM objective values in order to plot convergence curves
# This is required for the dual solver which optimizes the dual objective function
def getCSVMPrimalDualObjVals(alpha):
	global w_SDCM, b_SDCM
	hingeLoss = np.maximum(1 - np.multiply((X.dot(w_SDCM) + b_SDCM), y), 0)
	objPrimal = 0.5 * w_SDCM.dot(w_SDCM) + C * np.sum(hingeLoss)
	# Recall that b is supposed to be treated as the last coordinate of w
	objDual = np.sum(alpha) - 0.5 * np.square(np.linalg.norm(w_SDCM)) - 0.5 * b_SDCM * b_SDCM

	return np.array([objPrimal, objDual])


# In[9]:
################################
# Non Editable Region Starting #
################################
def solver( X, y, timeout, spacing ):
	(n, d) = X.shape
	t = 0
	totTime = 0
	
	# W is the model vector and will get returned once timeout happens
	# B is the bias term that will get returned once timeout happens
	# The bias term is optional. If you feel you do not need a bias term at all, just keep it set to 0
	# However, if you do end up using a bias term, you are allowed to internally use a model vector
	# that hides the bias inside the model vector e.g. by defining a new variable such as
	# W_extended = np.concatenate( ( W, [B] ) )
	# However, you must maintain W and B variables separately as well so that they can get
	# returned when timeout happens. Take care to update W, B whenever you update your W_extended
	# variable otherwise you will get wrong results.
	# Also note that the dimensionality of W may be larger or smaller than 9
	
	W = []
	B = 0
	tic = tm.perf_counter()
################################
#  Non Editable Region Ending  #
################################
	X = get_features(X_raw)
	y = np.where(y > 0, 1, -1)

	# You may reinitialize W, B to your liking here e.g. set W to its correct dimensionality
	# You may also define new variables here e.g. step_length, mini-batch size etc

################################
# Non Editable Region Starting #
################################
	while True:
		t = t + 1
		if t % spacing == 0:
			toc = tm.perf_counter()
			totTime = totTime + (toc - tic)
			if totTime > timeout:
				return ( W.reshape( ( W.size, ) ), B, totTime )			# Reshape W as a vector
			else:
				tic = tm.perf_counter()
################################
#  Non Editable Region Ending  #
################################
	def mySVM(X):
		return X.dot(w) + b

	# Stochastic Dual Coordinate Maximization
	def doCoordOptCSVMDual(alpha, i, t):
		global w_SDCM, b_SDCM, normSq
		x = X[i, :]

		# Find the unconstrained new optimal value of alpha_i
		# It takes only O(d) time to do so because of our clever book keeping
		newAlphai = alpha[i] + (1 - y[i] * (x.dot(w_SDCM) + b_SDCM)) / normSq[i]

		# Make sure that the constraints are satisfied. This takes only O(1) time
		if newAlphai > C:
			newAlphai = C
		if newAlphai < 0:
			newAlphai = 0

		# Update the primal model vector and bias values to ensure bookkeeping is proper
		# Doing these bookkeeping updates also takes only O(d) time
		w_SDCM = w_SDCM + (newAlphai - alpha[i]) * y[i] * x
		b_SDCM = b_SDCM + (newAlphai - alpha[i]) * y[i]

		return newAlphai

	# Get the primal and the dual CSVM objective values in order to plot convergence curves
	# This is required for the dual solver which optimizes the dual objective function
	def getCSVMPrimalDualObjVals(alpha):
		global w_SDCM, b_SDCM
		hingeLoss = np.maximum(1 - np.multiply((X.dot(w_SDCM) + b_SDCM), y), 0)
		objPrimal = 0.5 * w_SDCM.dot(w_SDCM) + C * np.sum(hingeLoss)
		# Recall that b is supposed to be treated as the last coordinate of w
		objDual = np.sum(alpha) - 0.5 * np.square(np.linalg.norm(w_SDCM)) - 0.5 * b_SDCM * b_SDCM

		return np.array([objPrimal, objDual])

	# In[11]:

	C = .1

	coordFunc = coordinateGenerator("randperm", y.size)

	initDual = C * np.ones((y.size,))

	normSq = np.square(np.linalg.norm(X, axis=1)) + 1

	alphayInit = np.multiply(initDual, y)
	w_SDCM = X.T.dot(alphayInit)

	b_SDCM = initDual.dot(y)

	(alpha_SDCM, obj_SDCM, time_SDCM) = doSDCM(doCoordOptCSVMDual, coordFunc, getCSVMPrimalDualObjVals, initDual,
											   horizon=5000)

	# In[12]:

	fig1 = getFigure(7, 7)
	plt.figure(fig1.number)
	primal_SDCM = [obj_SDCM[i][0] for i in range(len(obj_SDCM))]
	dual_SDCM = [obj_SDCM[i][1] for i in range(len(obj_SDCM))]
	plt.plot(time_SDCM, primal_SDCM, color='b', linestyle='-', label="SDCM Primal Obj Val")
	plt.plot(time_SDCM, dual_SDCM, color='b', linestyle=':', label="SDCM Dual Obj Val")
	plt.legend()
	plt.xlabel("Elapsed time (sec)")
	plt.ylabel("C-SVM Objective value")

	# plt.ylim( np.median( dual_SDCM ), np.median( primal_SDCM ) )

	plt.show()

	# In[13]:

	def eval(theta, name):
		global X_t, y_t
		global w, b
		w = theta[0:-1]
		b = theta[-1]
		y_t_pred = mySVM(X_t)
		y_t_pred = np.where(y_t_pred > 0, 1, -1)
		print(name, np.average(y_t == y_t_pred))

	eval(np.append(w_SDCM, b_SDCM), "SDCM")

	# In[14]:

	# Vanilla Gradient Descent
	def getCSVMGrad(theta, t):
		w = theta[0:-1]
		b = theta[-1]
		discriminant = np.multiply((X.dot(w) + b), y)
		g = np.zeros((y.size,))
		g[discriminant < 1] = -1
		delb = C * g.dot(y)
		delw = w + C * (X.T * g).dot(y)
		return np.append(delw, delb)

	# Stochastic Gradient Descent
	def getCSVMSGrad(theta, t):
		w = theta[0:-1]
		b = theta[-1]
		n = y.size
		i = random.randint(0, n - 1)
		x = X[i, :]
		discriminant = (x.dot(w) + b) * y[i]
		g = 0
		if discriminant < 1:
			g = -1
		delb = C * n * g * y[i]
		delw = w + C * n * (x * g) * y[i]
		return np.append(delw, delb)

	# Mini-batch Stochastic Gradient Descent
	def getCSVMMBGrad(theta, t):
		w = theta[0:-1]
		b = theta[-1]
		n = y.size
		# Be careful not to ask for more samples than there are training points
		# otherwise the sample() routine will throw an exception
		B_eff = min(B, n)
		samples = random.sample(range(0, n), B_eff)
		X_ = X[samples, :]
		y_ = y[samples]
		discriminant = np.multiply((X_.dot(w) + b), y_)
		g = np.zeros((B_eff,))
		g[discriminant < 1] = -1
		delb = C * n / B_eff * g.dot(y_)
		delw = w + C * n / B_eff * (X_.T * g).dot(y_)
		return np.append(delw, delb)

	# Variable Batch-size Stochastic Gradient Descent
	def getCSVMVarMBGrad(theta, t):
		w = theta[0:-1]
		b = theta[-1]
		n = y.size
		# Increase the batch size every few iterations -- there are two tuneable hyperparameters here
		# How frequently to update the batch size and how much to increase it at each update
		B_eff = min(B * int(pow(1.2, t // 40)), n)
		samples = random.sample(range(0, n), B_eff)
		X_ = X[samples, :]
		y_ = y[samples]
		discriminant = np.multiply((X_.dot(w) + b), y_)
		g = np.zeros((B_eff,))
		g[discriminant < 1] = -1
		delb = C * n / B_eff * g.dot(y_)
		delw = w + C * n / B_eff * (X_.T * g).dot(y_)
		return np.append(delw, delb)

	# Get the CSVM objective value in order to plot convergence curves
	def getCSVMObjVal(theta):
		w = theta[0:-1]
		b = theta[-1]
		hingeLoss = np.maximum(1 - np.multiply((X.dot(w) + b), y), 0)
		return 0.5 * w.dot(w) + C * np.sum(hingeLoss)

	# In[15]:

	def mySVM(X):
		return X.dot(w) + b

	C = .1
	eta = .01
	B = 10
	d = X.shape[1]

	init = np.zeros((d + 1,))
	stepFunc = stepLengthGenerator("linear", eta)

	(thetaGD, objGD, timeGD) = doGD(getCSVMGrad, stepFunc, getCSVMObjVal, init, horizon=500, doModelAveraging=True)

	# In[26]:

	eval(thetaGD, "GD")

	fig2 = getFigure(7, 7)
	plt.figure(fig2.number)
	plt.plot(timeGD, objGD, color='k', linestyle='--', label="GD")

	plt.xlabel("Elapsed time (sec)")
	plt.ylabel("C-SVM Objective value")
	plt.legend()
	# Plot the results of the last blah iterates of all methods
	blah = 500
	# plt.ylim( 0, max(primal_SDCM[-blah], objGD[-blah]) )
	# plt.xlim( 0, 0.1 )
	plt.show()

	# In[ ]:
		# Write all code to perform your method updates here within the infinite while loop
		# The infinite loop will terminate once timeout is reached
		# Do not try to bypass the timer check e.g. by using continue
		# It is very easy for us to detect such bypasses which will be strictly penalized
		
		# Note that most likely, you should be using get_features( X ) and get_renamed_labels( y )
		# in this part of the code instead of X and y -- please take care
		
		# Please note that once timeout is reached, the code will simply return W, B
		# Thus, if you wish to return the average model (as is sometimes done for GD),
		# you need to make sure that W, B store the averages at all times
		# One way to do so is to define a "running" variable w_run, b_run
		# Make all GD updates to W_run e.g. W_run = W_run - step * delW (similarly for B_run)
		# Then use a running average formula to update W (similarly for B)
		# W = (W * (t-1) + W_run)/t
		# This way, W, B will always store the averages and can be returned at any time
		# In this scheme, W, B play the role of the "cumulative" variables in the course module optLib (see the cs771 library)
		# W_run, B_run on the other hand, play the role of the "theta" variable in the course module optLib (see the cs771 library)
		
	return ( W.reshape( ( W.size, ) ), B, totTime )			# This return statement will never be reached